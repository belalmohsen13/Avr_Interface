/*
 * SW_config.c
 *
 *  Created on: Jul 27, 2024
 *      Author: user
 */
#include "STD_Types.h"
#include "ErrorState.h"

#include "SW.priv.h"
#include "SW_config.h"

#include "DIO_int.h"

SW_t SW_AstrSwitchStates[Num_Switches]={
{DIO_u8PORTA,DIO_u8PIN0,DIO_u8HIGH},
{DIO_u8PORTB,DIO_u8PIN1,DIO_u8HIGH},
{DIO_u8PORTC,DIO_u8PIN2,DIO_u8LOW}
};
