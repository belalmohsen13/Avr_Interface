/*
 * SW.priv.h
 *
 *  Created on: Jul 27, 2024
 *      Author: user
 */

#ifndef SW_PRIV_H_
#define SW_PRIV_H_



#endif /* SW_PRIV_H_ */
