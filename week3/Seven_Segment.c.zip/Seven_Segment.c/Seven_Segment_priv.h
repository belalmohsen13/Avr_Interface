/*
 * Seven_Segment_priv.h
 *
 *  Created on: Jul 31, 2024
 *      Author: user
 */

#ifndef SEVEN_SEGMENT_PRIV_H_
#define SEVEN_SEGMENT_PRIV_H_

#define Not_Connected 0
#define Connected 1

#define Common_Cathode 1
#define Common_anode 0

#endif /* SEVEN_SEGMENT_PRIV_H_ */
